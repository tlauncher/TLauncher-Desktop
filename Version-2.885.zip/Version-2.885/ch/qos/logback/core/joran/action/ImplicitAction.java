/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.joran.action;

import ch.qos.logback.core.joran.action.Action;
import ch.qos.logback.core.joran.spi.ElementPath;
import ch.qos.logback.core.joran.spi.InterpretationContext;
import org.xml.sax.Attributes;

public abstract class ImplicitAction
extends Action {
    public abstract boolean isApplicable(ElementPath var1, Attributes var2, InterpretationContext var3);
}

