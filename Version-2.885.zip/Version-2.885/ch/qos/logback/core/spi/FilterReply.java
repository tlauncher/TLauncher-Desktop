/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.spi;

public enum FilterReply {
    DENY,
    NEUTRAL,
    ACCEPT;

}

