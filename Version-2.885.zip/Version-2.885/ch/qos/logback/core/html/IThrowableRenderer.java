/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.html;

public interface IThrowableRenderer<E> {
    public void render(StringBuilder var1, E var2);
}

