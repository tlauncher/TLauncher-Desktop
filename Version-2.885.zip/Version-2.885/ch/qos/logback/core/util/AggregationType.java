/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.util;

public enum AggregationType {
    NOT_FOUND,
    AS_BASIC_PROPERTY,
    AS_COMPLEX_PROPERTY,
    AS_BASIC_PROPERTY_COLLECTION,
    AS_COMPLEX_PROPERTY_COLLECTION;

}

