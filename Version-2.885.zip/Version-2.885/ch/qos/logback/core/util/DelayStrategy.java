/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.util;

public interface DelayStrategy {
    public long nextDelay();
}

