/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.rolling.helper;

public enum CompressionMode {
    NONE,
    GZ,
    ZIP;

}

