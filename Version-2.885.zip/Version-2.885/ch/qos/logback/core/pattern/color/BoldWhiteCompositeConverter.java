/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.pattern.color;

import ch.qos.logback.core.pattern.color.ForegroundCompositeConverterBase;

public class BoldWhiteCompositeConverter<E>
extends ForegroundCompositeConverterBase<E> {
    @Override
    protected String getForegroundColorCode(E event) {
        return "1;37";
    }
}

