/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.classic.net;

class SocketAcceptor
extends Thread {
    SocketAcceptor() {
    }

    @Override
    public void run() {
    }
}

