/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.os;

import by.gdev.util.OSInfo;
import by.gdev.util.os.LinuxExecutor;
import by.gdev.util.os.MacExecutor;
import by.gdev.util.os.OSExecutor;
import by.gdev.util.os.WindowsExecutor;

public class OSExecutorFactoryMethod {
    private OSInfo.OSType osType = OSInfo.getOSType();

    public OSExecutor createOsExecutor() {
        switch (this.osType) {
            default: {
                return new WindowsExecutor();
            }
            case LINUX: {
                return new LinuxExecutor();
            }
            case MACOSX: 
        }
        return new MacExecutor();
    }

    public OSInfo.OSType getOsType() {
        return this.osType;
    }

    public void setOsType(OSInfo.OSType osType) {
        this.osType = osType;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof OSExecutorFactoryMethod)) {
            return false;
        }
        OSExecutorFactoryMethod other = (OSExecutorFactoryMethod)o;
        if (!other.canEqual(this)) {
            return false;
        }
        OSInfo.OSType this$osType = this.getOsType();
        OSInfo.OSType other$osType = other.getOsType();
        return !(this$osType == null ? other$osType != null : !((Object)((Object)this$osType)).equals((Object)other$osType));
    }

    protected boolean canEqual(Object other) {
        return other instanceof OSExecutorFactoryMethod;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        OSInfo.OSType $osType = this.getOsType();
        result = result * 59 + ($osType == null ? 43 : ((Object)((Object)$osType)).hashCode());
        return result;
    }

    public String toString() {
        return "OSExecutorFactoryMethod(osType=" + (Object)((Object)this.getOsType()) + ")";
    }
}

