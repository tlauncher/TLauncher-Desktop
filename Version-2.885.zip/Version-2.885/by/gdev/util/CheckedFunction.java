/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util;

@FunctionalInterface
public interface CheckedFunction<T, R> {
    public R apply(T var1) throws Exception;
}

