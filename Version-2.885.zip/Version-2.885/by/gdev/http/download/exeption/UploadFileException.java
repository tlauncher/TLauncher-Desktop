/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.exeption;

import java.io.IOException;

public class UploadFileException
extends IOException {
    private static final long serialVersionUID = -2684927056566219164L;
    private String uri;
    private String localPath;

    public UploadFileException(String uri, String localPath, String message) {
        super(message);
        this.uri = uri;
        this.localPath = localPath;
    }

    public String getUri() {
        return this.uri;
    }

    public String getLocalPath() {
        return this.localPath;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    @Override
    public String toString() {
        return "UploadFileException(uri=" + this.getUri() + ", localPath=" + this.getLocalPath() + ")";
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof UploadFileException)) {
            return false;
        }
        UploadFileException other = (UploadFileException)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        String this$uri = this.getUri();
        String other$uri = other.getUri();
        if (this$uri == null ? other$uri != null : !this$uri.equals(other$uri)) {
            return false;
        }
        String this$localPath = this.getLocalPath();
        String other$localPath = other.getLocalPath();
        return !(this$localPath == null ? other$localPath != null : !this$localPath.equals(other$localPath));
    }

    protected boolean canEqual(Object other) {
        return other instanceof UploadFileException;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = super.hashCode();
        String $uri = this.getUri();
        result = result * 59 + ($uri == null ? 43 : $uri.hashCode());
        String $localPath = this.getLocalPath();
        result = result * 59 + ($localPath == null ? 43 : $localPath.hashCode());
        return result;
    }
}

