/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.service;

import by.gdev.util.model.download.Metadata;
import java.io.IOException;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface FileCacheService {
    public Path getRawObject(String var1, boolean var2) throws IOException, NoSuchAlgorithmException;

    public Path getRawObject(List<String> var1, Metadata var2, boolean var3) throws IOException, NoSuchAlgorithmException;
}

