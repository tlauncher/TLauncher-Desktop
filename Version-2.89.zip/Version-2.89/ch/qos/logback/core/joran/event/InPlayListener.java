/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.joran.event;

import ch.qos.logback.core.joran.event.SaxEvent;

public interface InPlayListener {
    public void inPlay(SaxEvent var1);
}

