/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.joran.spi.NoAutoStart;

public class NoAutoStartUtil {
    public static boolean notMarkedWithNoAutoStart(Object o) {
        if (o == null) {
            return false;
        }
        Class<?> clazz = o.getClass();
        NoAutoStart a = clazz.getAnnotation(NoAutoStart.class);
        return a == null;
    }
}

