/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.helpers;

import ch.qos.logback.core.AppenderBase;

public final class NOPAppender<E>
extends AppenderBase<E> {
    @Override
    protected void append(E eventObject) {
    }
}

