/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.rolling.helper;

public interface MonoTypedConverter {
    public boolean isApplicable(Object var1);
}

