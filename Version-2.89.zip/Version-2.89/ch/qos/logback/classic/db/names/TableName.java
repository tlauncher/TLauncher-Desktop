/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.classic.db.names;

public enum TableName {
    LOGGING_EVENT,
    LOGGING_EVENT_PROPERTY,
    LOGGING_EVENT_EXCEPTION;

}

