/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.classic.pattern;

public interface Abbreviator {
    public String abbreviate(String var1);
}

