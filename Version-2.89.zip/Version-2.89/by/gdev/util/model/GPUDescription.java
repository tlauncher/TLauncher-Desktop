/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.model;

public class GPUDescription {
    String name;
    String chipType;
    String memory;

    public String getName() {
        return this.name;
    }

    public String getChipType() {
        return this.chipType;
    }

    public String getMemory() {
        return this.memory;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setChipType(String chipType) {
        this.chipType = chipType;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof GPUDescription)) {
            return false;
        }
        GPUDescription other = (GPUDescription)o;
        if (!other.canEqual(this)) {
            return false;
        }
        String this$name = this.getName();
        String other$name = other.getName();
        if (this$name == null ? other$name != null : !this$name.equals(other$name)) {
            return false;
        }
        String this$chipType = this.getChipType();
        String other$chipType = other.getChipType();
        if (this$chipType == null ? other$chipType != null : !this$chipType.equals(other$chipType)) {
            return false;
        }
        String this$memory = this.getMemory();
        String other$memory = other.getMemory();
        return !(this$memory == null ? other$memory != null : !this$memory.equals(other$memory));
    }

    protected boolean canEqual(Object other) {
        return other instanceof GPUDescription;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        String $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        String $chipType = this.getChipType();
        result = result * 59 + ($chipType == null ? 43 : $chipType.hashCode());
        String $memory = this.getMemory();
        result = result * 59 + ($memory == null ? 43 : $memory.hashCode());
        return result;
    }

    public String toString() {
        return "GPUDescription(name=" + this.getName() + ", chipType=" + this.getChipType() + ", memory=" + this.getMemory() + ")";
    }
}

