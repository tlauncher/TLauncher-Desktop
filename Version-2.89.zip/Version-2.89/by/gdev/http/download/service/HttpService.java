/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.service;

import by.gdev.http.download.model.RequestMetadata;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public interface HttpService {
    public RequestMetadata getRequestByUrlAndSave(String var1, Path var2) throws IOException;

    public RequestMetadata getMetaByUrl(String var1) throws IOException;

    public String getRequestByUrl(String var1) throws IOException;

    public String getRequestByUrl(String var1, Map<String, String> var2) throws IOException;
}

