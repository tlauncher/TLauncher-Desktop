/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.exeption;

public class StatusExeption
extends Exception {
    public StatusExeption(String status) {
        super(status);
    }
}

