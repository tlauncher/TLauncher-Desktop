/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.model;

public enum Headers {
    SHA1("SHA-1"),
    ETAG("ETag"),
    CONTENTLENGTH("Content-Length"),
    LASTMODIFIED("Last-Modified");

    private final String value;

    public String getValue() {
        return this.value;
    }

    private Headers(String value) {
        this.value = value;
    }
}

