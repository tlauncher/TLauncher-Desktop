/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.handler;

import by.gdev.http.upload.download.downloader.DownloadElement;

public interface PostHandler {
    public void postProcessDownloadElement(DownloadElement var1);
}

