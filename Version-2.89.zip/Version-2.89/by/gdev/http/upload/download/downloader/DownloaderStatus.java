/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.upload.download.downloader;

import by.gdev.http.upload.download.downloader.DownloaderStatusEnum;
import java.time.Duration;
import java.util.List;

public class DownloaderStatus {
    private Duration duration;
    private double speed;
    private long downloadSize;
    private long allDownloadSize;
    private Integer leftFiles;
    private Integer allFiles;
    private List<Throwable> throwables;
    private DownloaderStatusEnum downloaderStatusEnum;

    public Duration getDuration() {
        return this.duration;
    }

    public double getSpeed() {
        return this.speed;
    }

    public long getDownloadSize() {
        return this.downloadSize;
    }

    public long getAllDownloadSize() {
        return this.allDownloadSize;
    }

    public Integer getLeftFiles() {
        return this.leftFiles;
    }

    public Integer getAllFiles() {
        return this.allFiles;
    }

    public List<Throwable> getThrowables() {
        return this.throwables;
    }

    public DownloaderStatusEnum getDownloaderStatusEnum() {
        return this.downloaderStatusEnum;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void setDownloadSize(long downloadSize) {
        this.downloadSize = downloadSize;
    }

    public void setAllDownloadSize(long allDownloadSize) {
        this.allDownloadSize = allDownloadSize;
    }

    public void setLeftFiles(Integer leftFiles) {
        this.leftFiles = leftFiles;
    }

    public void setAllFiles(Integer allFiles) {
        this.allFiles = allFiles;
    }

    public void setThrowables(List<Throwable> throwables) {
        this.throwables = throwables;
    }

    public void setDownloaderStatusEnum(DownloaderStatusEnum downloaderStatusEnum) {
        this.downloaderStatusEnum = downloaderStatusEnum;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof DownloaderStatus)) {
            return false;
        }
        DownloaderStatus other = (DownloaderStatus)o;
        if (!other.canEqual(this)) {
            return false;
        }
        Duration this$duration = this.getDuration();
        Duration other$duration = other.getDuration();
        if (this$duration == null ? other$duration != null : !((Object)this$duration).equals(other$duration)) {
            return false;
        }
        if (Double.compare(this.getSpeed(), other.getSpeed()) != 0) {
            return false;
        }
        if (this.getDownloadSize() != other.getDownloadSize()) {
            return false;
        }
        if (this.getAllDownloadSize() != other.getAllDownloadSize()) {
            return false;
        }
        Integer this$leftFiles = this.getLeftFiles();
        Integer other$leftFiles = other.getLeftFiles();
        if (this$leftFiles == null ? other$leftFiles != null : !((Object)this$leftFiles).equals(other$leftFiles)) {
            return false;
        }
        Integer this$allFiles = this.getAllFiles();
        Integer other$allFiles = other.getAllFiles();
        if (this$allFiles == null ? other$allFiles != null : !((Object)this$allFiles).equals(other$allFiles)) {
            return false;
        }
        List<Throwable> this$throwables = this.getThrowables();
        List<Throwable> other$throwables = other.getThrowables();
        if (this$throwables == null ? other$throwables != null : !((Object)this$throwables).equals(other$throwables)) {
            return false;
        }
        DownloaderStatusEnum this$downloaderStatusEnum = this.getDownloaderStatusEnum();
        DownloaderStatusEnum other$downloaderStatusEnum = other.getDownloaderStatusEnum();
        return !(this$downloaderStatusEnum == null ? other$downloaderStatusEnum != null : !((Object)((Object)this$downloaderStatusEnum)).equals((Object)other$downloaderStatusEnum));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DownloaderStatus;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Duration $duration = this.getDuration();
        result = result * 59 + ($duration == null ? 43 : ((Object)$duration).hashCode());
        long $speed = Double.doubleToLongBits(this.getSpeed());
        result = result * 59 + (int)($speed >>> 32 ^ $speed);
        long $downloadSize = this.getDownloadSize();
        result = result * 59 + (int)($downloadSize >>> 32 ^ $downloadSize);
        long $allDownloadSize = this.getAllDownloadSize();
        result = result * 59 + (int)($allDownloadSize >>> 32 ^ $allDownloadSize);
        Integer $leftFiles = this.getLeftFiles();
        result = result * 59 + ($leftFiles == null ? 43 : ((Object)$leftFiles).hashCode());
        Integer $allFiles = this.getAllFiles();
        result = result * 59 + ($allFiles == null ? 43 : ((Object)$allFiles).hashCode());
        List<Throwable> $throwables = this.getThrowables();
        result = result * 59 + ($throwables == null ? 43 : ((Object)$throwables).hashCode());
        DownloaderStatusEnum $downloaderStatusEnum = this.getDownloaderStatusEnum();
        result = result * 59 + ($downloaderStatusEnum == null ? 43 : ((Object)((Object)$downloaderStatusEnum)).hashCode());
        return result;
    }

    public String toString() {
        return "DownloaderStatus(duration=" + this.getDuration() + ", speed=" + this.getSpeed() + ", downloadSize=" + this.getDownloadSize() + ", allDownloadSize=" + this.getAllDownloadSize() + ", leftFiles=" + this.getLeftFiles() + ", allFiles=" + this.getAllFiles() + ", throwables=" + this.getThrowables() + ", downloaderStatusEnum=" + (Object)((Object)this.getDownloaderStatusEnum()) + ")";
    }
}

