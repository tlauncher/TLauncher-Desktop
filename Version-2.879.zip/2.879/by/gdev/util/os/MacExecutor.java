/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.os;

import by.gdev.util.model.GPUsDescriptionDTO;
import by.gdev.util.os.LinuxExecutor;
import java.io.IOException;

public class MacExecutor
extends LinuxExecutor {
    @Override
    public GPUsDescriptionDTO getGPUInfo() throws IOException, InterruptedException {
        String res = this.execute("system_profiler SPDisplaysDataType", 60);
        return this.getGPUInfo1(res, "chipset model:");
    }
}

