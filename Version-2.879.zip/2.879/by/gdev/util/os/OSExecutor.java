/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.os;

import by.gdev.util.model.GPUDriverVersion;
import by.gdev.util.model.GPUsDescriptionDTO;
import java.io.IOException;

public interface OSExecutor {
    public String execute(String var1, int var2) throws IOException, InterruptedException;

    public GPUsDescriptionDTO getGPUInfo() throws IOException, InterruptedException;

    public GPUDriverVersion getGPUDriverVersion() throws IOException, InterruptedException;
}

