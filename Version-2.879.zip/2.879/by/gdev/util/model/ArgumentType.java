/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.model;

public enum ArgumentType {
    JVM,
    APP;

}

