/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.model.download;

import by.gdev.util.model.download.Metadata;
import java.util.List;

public class Repo {
    private List<String> repositories;
    private List<Metadata> resources;
    private boolean remoteServerSHA1;

    public List<String> getRepositories() {
        return this.repositories;
    }

    public List<Metadata> getResources() {
        return this.resources;
    }

    public boolean isRemoteServerSHA1() {
        return this.remoteServerSHA1;
    }

    public void setRepositories(List<String> repositories) {
        this.repositories = repositories;
    }

    public void setResources(List<Metadata> resources) {
        this.resources = resources;
    }

    public void setRemoteServerSHA1(boolean remoteServerSHA1) {
        this.remoteServerSHA1 = remoteServerSHA1;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Repo)) {
            return false;
        }
        Repo other = (Repo)o;
        if (!other.canEqual(this)) {
            return false;
        }
        List<String> this$repositories = this.getRepositories();
        List<String> other$repositories = other.getRepositories();
        if (this$repositories == null ? other$repositories != null : !((Object)this$repositories).equals(other$repositories)) {
            return false;
        }
        List<Metadata> this$resources = this.getResources();
        List<Metadata> other$resources = other.getResources();
        if (this$resources == null ? other$resources != null : !((Object)this$resources).equals(other$resources)) {
            return false;
        }
        return this.isRemoteServerSHA1() == other.isRemoteServerSHA1();
    }

    protected boolean canEqual(Object other) {
        return other instanceof Repo;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<String> $repositories = this.getRepositories();
        result = result * 59 + ($repositories == null ? 43 : ((Object)$repositories).hashCode());
        List<Metadata> $resources = this.getResources();
        result = result * 59 + ($resources == null ? 43 : ((Object)$resources).hashCode());
        result = result * 59 + (this.isRemoteServerSHA1() ? 79 : 97);
        return result;
    }

    public String toString() {
        return "Repo(repositories=" + this.getRepositories() + ", resources=" + this.getResources() + ", remoteServerSHA1=" + this.isRemoteServerSHA1() + ")";
    }
}

