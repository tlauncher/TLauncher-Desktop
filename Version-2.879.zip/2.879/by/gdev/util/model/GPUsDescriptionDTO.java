/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.util.model;

import by.gdev.util.model.GPUDescription;
import java.util.List;

public class GPUsDescriptionDTO {
    List<GPUDescription> gpus;
    String rawDescription;

    public List<GPUDescription> getGpus() {
        return this.gpus;
    }

    public String getRawDescription() {
        return this.rawDescription;
    }

    public void setGpus(List<GPUDescription> gpus) {
        this.gpus = gpus;
    }

    public void setRawDescription(String rawDescription) {
        this.rawDescription = rawDescription;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof GPUsDescriptionDTO)) {
            return false;
        }
        GPUsDescriptionDTO other = (GPUsDescriptionDTO)o;
        if (!other.canEqual(this)) {
            return false;
        }
        List<GPUDescription> this$gpus = this.getGpus();
        List<GPUDescription> other$gpus = other.getGpus();
        if (this$gpus == null ? other$gpus != null : !((Object)this$gpus).equals(other$gpus)) {
            return false;
        }
        String this$rawDescription = this.getRawDescription();
        String other$rawDescription = other.getRawDescription();
        return !(this$rawDescription == null ? other$rawDescription != null : !this$rawDescription.equals(other$rawDescription));
    }

    protected boolean canEqual(Object other) {
        return other instanceof GPUsDescriptionDTO;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<GPUDescription> $gpus = this.getGpus();
        result = result * 59 + ($gpus == null ? 43 : ((Object)$gpus).hashCode());
        String $rawDescription = this.getRawDescription();
        result = result * 59 + ($rawDescription == null ? 43 : $rawDescription.hashCode());
        return result;
    }

    public String toString() {
        return "GPUsDescriptionDTO(gpus=" + this.getGpus() + ", rawDescription=" + this.getRawDescription() + ")";
    }
}

