/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package by.gdev.http.download.handler;

import by.gdev.http.download.handler.PostHandler;
import by.gdev.http.upload.download.downloader.DownloadElement;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimvolicLinkHandler
implements PostHandler {
    private static final Logger log = LoggerFactory.getLogger(SimvolicLinkHandler.class);

    @Override
    public void postProcessDownloadElement(DownloadElement e) {
        if (!StringUtils.isEmpty((CharSequence)e.getMetadata().getLink())) {
            try {
                Path target = Paths.get(e.getPathToDownload(), e.getMetadata().getLink());
                Path link = Paths.get(e.getPathToDownload(), e.getMetadata().getPath());
                if (Files.exists(link, new LinkOption[0])) {
                    Files.delete(link);
                }
                Files.createSymbolicLink(link.toAbsolutePath(), target.toAbsolutePath(), new FileAttribute[0]);
            }
            catch (IOException ex) {
                log.error("Error to create simvolic link", ex);
            }
        }
    }
}

