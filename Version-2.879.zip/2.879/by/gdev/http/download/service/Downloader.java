/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.service;

import by.gdev.http.download.exeption.StatusExeption;
import by.gdev.http.upload.download.downloader.DownloaderContainer;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

public interface Downloader {
    public void addContainer(DownloaderContainer var1) throws IOException;

    public void startDownload(boolean var1) throws InterruptedException, ExecutionException, StatusExeption, IOException;

    public void cancelDownload();
}

