/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Type;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

public interface GsonService {
    public <T> T getObject(String var1, Class<T> var2, boolean var3) throws FileNotFoundException, IOException, NoSuchAlgorithmException;

    public <T> T getObjectByUrls(List<String> var1, String var2, Class<T> var3, boolean var4) throws FileNotFoundException, IOException, NoSuchAlgorithmException;

    public <T> T getObjectWithoutSaving(String var1, Class<T> var2) throws IOException;

    public <T> T getObjectWithoutSaving(String var1, Class<T> var2, Map<String, String> var3) throws IOException;

    public <T> T getObjectWithoutSaving(String var1, Type var2) throws IOException;

    public <T> T getObjectWithoutSaving(String var1, Type var2, Map<String, String> var3) throws IOException;
}

