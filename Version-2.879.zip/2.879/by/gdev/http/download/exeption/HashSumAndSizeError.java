/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.exeption;

import by.gdev.http.download.exeption.UploadFileException;

public class HashSumAndSizeError
extends UploadFileException {
    private static final long serialVersionUID = 6549216849433173596L;

    public HashSumAndSizeError(String uri, String localPath, String message) {
        super(uri, localPath, message);
    }
}

