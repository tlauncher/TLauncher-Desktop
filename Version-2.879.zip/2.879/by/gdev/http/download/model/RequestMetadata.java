/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.download.model;

public class RequestMetadata {
    private String contentLength;
    private String lastModified;
    private String eTag;
    private String sha1;

    public String getContentLength() {
        return this.contentLength;
    }

    public String getLastModified() {
        return this.lastModified;
    }

    public String getETag() {
        return this.eTag;
    }

    public String getSha1() {
        return this.sha1;
    }

    public void setContentLength(String contentLength) {
        this.contentLength = contentLength;
    }

    public void setLastModified(String lastModified) {
        this.lastModified = lastModified;
    }

    public void setETag(String eTag) {
        this.eTag = eTag;
    }

    public void setSha1(String sha1) {
        this.sha1 = sha1;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof RequestMetadata)) {
            return false;
        }
        RequestMetadata other = (RequestMetadata)o;
        if (!other.canEqual(this)) {
            return false;
        }
        String this$contentLength = this.getContentLength();
        String other$contentLength = other.getContentLength();
        if (this$contentLength == null ? other$contentLength != null : !this$contentLength.equals(other$contentLength)) {
            return false;
        }
        String this$lastModified = this.getLastModified();
        String other$lastModified = other.getLastModified();
        if (this$lastModified == null ? other$lastModified != null : !this$lastModified.equals(other$lastModified)) {
            return false;
        }
        String this$eTag = this.getETag();
        String other$eTag = other.getETag();
        if (this$eTag == null ? other$eTag != null : !this$eTag.equals(other$eTag)) {
            return false;
        }
        String this$sha1 = this.getSha1();
        String other$sha1 = other.getSha1();
        return !(this$sha1 == null ? other$sha1 != null : !this$sha1.equals(other$sha1));
    }

    protected boolean canEqual(Object other) {
        return other instanceof RequestMetadata;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        String $contentLength = this.getContentLength();
        result = result * 59 + ($contentLength == null ? 43 : $contentLength.hashCode());
        String $lastModified = this.getLastModified();
        result = result * 59 + ($lastModified == null ? 43 : $lastModified.hashCode());
        String $eTag = this.getETag();
        result = result * 59 + ($eTag == null ? 43 : $eTag.hashCode());
        String $sha1 = this.getSha1();
        result = result * 59 + ($sha1 == null ? 43 : $sha1.hashCode());
        return result;
    }

    public String toString() {
        return "RequestMetadata(contentLength=" + this.getContentLength() + ", lastModified=" + this.getLastModified() + ", eTag=" + this.getETag() + ", sha1=" + this.getSha1() + ")";
    }
}

