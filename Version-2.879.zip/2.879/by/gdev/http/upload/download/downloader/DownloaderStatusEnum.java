/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.upload.download.downloader;

public enum DownloaderStatusEnum {
    IDLE,
    WORK,
    DONE,
    CANCEL;

}

