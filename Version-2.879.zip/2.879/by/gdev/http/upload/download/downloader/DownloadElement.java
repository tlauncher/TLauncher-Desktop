/*
 * Decompiled with CFR 0.150.
 */
package by.gdev.http.upload.download.downloader;

import by.gdev.http.download.handler.PostHandler;
import by.gdev.util.model.download.Metadata;
import by.gdev.util.model.download.Repo;
import java.time.LocalTime;
import java.util.List;

public class DownloadElement {
    private List<PostHandler> handlers;
    private Metadata metadata;
    private String pathToDownload;
    private LocalTime start;
    private LocalTime end;
    private Repo repo;
    private volatile long downloadBytes;
    private volatile Throwable error;

    public List<PostHandler> getHandlers() {
        return this.handlers;
    }

    public Metadata getMetadata() {
        return this.metadata;
    }

    public String getPathToDownload() {
        return this.pathToDownload;
    }

    public LocalTime getStart() {
        return this.start;
    }

    public LocalTime getEnd() {
        return this.end;
    }

    public Repo getRepo() {
        return this.repo;
    }

    public long getDownloadBytes() {
        return this.downloadBytes;
    }

    public Throwable getError() {
        return this.error;
    }

    public void setHandlers(List<PostHandler> handlers) {
        this.handlers = handlers;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public void setPathToDownload(String pathToDownload) {
        this.pathToDownload = pathToDownload;
    }

    public void setStart(LocalTime start) {
        this.start = start;
    }

    public void setEnd(LocalTime end) {
        this.end = end;
    }

    public void setRepo(Repo repo) {
        this.repo = repo;
    }

    public void setDownloadBytes(long downloadBytes) {
        this.downloadBytes = downloadBytes;
    }

    public void setError(Throwable error) {
        this.error = error;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof DownloadElement)) {
            return false;
        }
        DownloadElement other = (DownloadElement)o;
        if (!other.canEqual(this)) {
            return false;
        }
        List<PostHandler> this$handlers = this.getHandlers();
        List<PostHandler> other$handlers = other.getHandlers();
        if (this$handlers == null ? other$handlers != null : !((Object)this$handlers).equals(other$handlers)) {
            return false;
        }
        Metadata this$metadata = this.getMetadata();
        Metadata other$metadata = other.getMetadata();
        if (this$metadata == null ? other$metadata != null : !((Object)this$metadata).equals(other$metadata)) {
            return false;
        }
        String this$pathToDownload = this.getPathToDownload();
        String other$pathToDownload = other.getPathToDownload();
        if (this$pathToDownload == null ? other$pathToDownload != null : !this$pathToDownload.equals(other$pathToDownload)) {
            return false;
        }
        LocalTime this$start = this.getStart();
        LocalTime other$start = other.getStart();
        if (this$start == null ? other$start != null : !((Object)this$start).equals(other$start)) {
            return false;
        }
        LocalTime this$end = this.getEnd();
        LocalTime other$end = other.getEnd();
        if (this$end == null ? other$end != null : !((Object)this$end).equals(other$end)) {
            return false;
        }
        Repo this$repo = this.getRepo();
        Repo other$repo = other.getRepo();
        if (this$repo == null ? other$repo != null : !((Object)this$repo).equals(other$repo)) {
            return false;
        }
        if (this.getDownloadBytes() != other.getDownloadBytes()) {
            return false;
        }
        Throwable this$error = this.getError();
        Throwable other$error = other.getError();
        return !(this$error == null ? other$error != null : !this$error.equals(other$error));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DownloadElement;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<PostHandler> $handlers = this.getHandlers();
        result = result * 59 + ($handlers == null ? 43 : ((Object)$handlers).hashCode());
        Metadata $metadata = this.getMetadata();
        result = result * 59 + ($metadata == null ? 43 : ((Object)$metadata).hashCode());
        String $pathToDownload = this.getPathToDownload();
        result = result * 59 + ($pathToDownload == null ? 43 : $pathToDownload.hashCode());
        LocalTime $start = this.getStart();
        result = result * 59 + ($start == null ? 43 : ((Object)$start).hashCode());
        LocalTime $end = this.getEnd();
        result = result * 59 + ($end == null ? 43 : ((Object)$end).hashCode());
        Repo $repo = this.getRepo();
        result = result * 59 + ($repo == null ? 43 : ((Object)$repo).hashCode());
        long $downloadBytes = this.getDownloadBytes();
        result = result * 59 + (int)($downloadBytes >>> 32 ^ $downloadBytes);
        Throwable $error = this.getError();
        result = result * 59 + ($error == null ? 43 : $error.hashCode());
        return result;
    }

    public String toString() {
        return "DownloadElement(handlers=" + this.getHandlers() + ", metadata=" + this.getMetadata() + ", pathToDownload=" + this.getPathToDownload() + ", start=" + this.getStart() + ", end=" + this.getEnd() + ", repo=" + this.getRepo() + ", downloadBytes=" + this.getDownloadBytes() + ", error=" + this.getError() + ")";
    }
}

