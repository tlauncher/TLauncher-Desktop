/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.joran.conditional;

public interface Condition {
    public boolean evaluate();
}

