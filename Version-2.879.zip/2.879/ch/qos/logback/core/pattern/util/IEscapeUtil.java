/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.pattern.util;

public interface IEscapeUtil {
    public void escape(String var1, StringBuffer var2, char var3, int var4);
}

