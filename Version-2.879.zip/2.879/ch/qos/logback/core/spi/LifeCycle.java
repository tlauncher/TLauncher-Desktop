/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.spi;

public interface LifeCycle {
    public void start();

    public void stop();

    public boolean isStarted();
}

