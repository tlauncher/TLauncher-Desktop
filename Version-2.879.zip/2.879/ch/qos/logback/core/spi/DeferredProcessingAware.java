/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.spi;

public interface DeferredProcessingAware {
    public void prepareForDeferredProcessing();
}

