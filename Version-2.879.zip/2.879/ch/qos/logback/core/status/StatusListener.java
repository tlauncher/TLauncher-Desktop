/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.status;

import ch.qos.logback.core.status.Status;

public interface StatusListener {
    public void addStatusEvent(Status var1);
}

