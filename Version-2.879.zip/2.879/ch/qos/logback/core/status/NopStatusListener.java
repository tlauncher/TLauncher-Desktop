/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.status;

import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.StatusListener;

public class NopStatusListener
implements StatusListener {
    @Override
    public void addStatusEvent(Status status) {
    }
}

