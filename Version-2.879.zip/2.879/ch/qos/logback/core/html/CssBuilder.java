/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.html;

public interface CssBuilder {
    public void addCss(StringBuilder var1);
}

